import asyncio
from concurrent.futures import ProcessPoolExecutor

import re
import time
from datetime import datetime

from selenium import webdriver
from selenium.webdriver.support.ui import Select

import requests
from bs4 import BeautifulSoup
from lxml.html import fromstring

driver = webdriver.Chrome('/Users/chef/Documents/Develop/Chrdrv/80/chromedriver')  # Optional argument, if not specified will search path.
base_url = 'https://www.supremenewyork.com/'
hot_filename = '/Users/chef/Documents/Develop/Python/resell_bots/hot.txt'
bad_urls_filename = '/Users/chef/Documents/Develop/Python/resell_bots/bad_urls.txt'
hot = [tuple(line.rstrip('\n').split(';')) for line in open(hot_filename, 'r')]
hot_db = {}
for e in hot:
    hot_db[e[0]] = (e[1], e[2])

try:
    with open(bad_urls_filename, 'r') as f:
        bad_urls = []
        for line in f:
            bad_urls.append(line.strip())
except IOError:
    bad_urls = []

new_bads = []

def browser_select_size(element_id, label):
    select = Select(driver.find_element_by_id(element_id))
    select.select_by_visible_text(label)

'''time.sleep(3) # Let the user actually see something!
assert False
search_box = driver.find_element_by_name('q')
search_box.send_keys('ChromeDriver')
search_box.submit()
time.sleep(5) # Let the user actually see something!
driver.quit()'''

def find_all_indexes(input_str, search_str):
    l1 = []
    length = len(input_str)
    index = 0
    while index < length:
        i = input_str.find(search_str, index)
        if i == -1:
            return l1
        l1.append(i)
        index = i + 1
    return l1

def get_hot_urls(urls):
    #print('get_hot_urls() urls count: ', len(urls))
    hot_urls = []
    for url in urls:
        r = requests.get(base_url + url)
        tree = fromstring(r.content)
        title_durty = tree.findtext('.//title')[9:] # cut 'Supreme:' in the start of the title
        idx = find_all_indexes(title_durty, ' - ')
        if idx:
            title = title_durty[:idx[-1]]
        if title in hot_db:
            hot_one = hot_db.get(title)
            soup = BeautifulSoup(r.content, 'lxml')
            colors_tags = soup.find_all('a', {'data-style-name' : re.compile(r'.*')})
            for color_tag in colors_tags:
                if color_tag['data-style-name'] != hot_one[0]:
                    continue
                hot_urls.append(color_tag['href'])
        else:
            bad_urls.append(url)

    return hot_urls

def get_urls_from_soup(soup):
    goods_urls = []
    for el in soup:
        url = el.find('a')['href']
        # cut the color parametr in url (last)
        idx = find_all_indexes(url, '/')
        url = url[:idx[-1]]
        if url in bad_urls:
            #print('catch')
            continue
        if url not in goods_urls:
            goods_urls.append(url)

    return goods_urls

def prepare_browser():
    if len(driver.window_handles) != len(hot):
        for i in range(len(hot)-1):
            driver.execute_script("window.open('');")

def attack_site():
    #driver.get('https://www.supremenewyork.com/shop/all')
    #soup = BeautifulSoup(driver.page_source, 'lxml')
    r = requests.get('https://www.supremenewyork.com/shop/all')
    soup = BeautifulSoup(r.content, 'lxml')
    print('--1: ', datetime.now())
    #print(soup.prettify())
    new_goods_urls = []
    articles = soup.find_all('article')
    print('--2: ', datetime.now())
    new_goods_urls = get_urls_from_soup(articles)
    print('--3: ', datetime.now())
    #with ProcessPoolExecutor() as executor:
    #for name, url in zip(articles, map(get_url_from_soup, articles)):
        #goods_urls.append(url)
    hot_urls = get_hot_urls(new_goods_urls)
    print('--4: ', datetime.now())

    prepare_browser()
    colors_list = []
    for i, url in enumerate(hot_urls):
        driver.switch_to.window(driver.window_handles[i])
        driver.get(base_url + url)
        soup = BeautifulSoup(driver.page_source, 'lxml')

        title = soup.find('h1', {'itemprop': 'name'})
        if title:
            good_entity = hot_db.get(title.text)

        if len(good_entity[1]) > 1: # symbol * in sizes tells us what any kind of size can be bought, 'Black' and etc have len() > 1
            size_select = soup.find('select', {'name': 'size'})
            if size_select:
                select = Select(driver.find_element_by_name('size'))
                select.select_by_visible_text(good_entity[1]) # select size option

        add_to_basket_btn = driver.find_element_by_name('commit')
        add_to_basket_btn.click()

    time.sleep(0.2)
    
    driver.execute_script("window.open('');")
    driver.switch_to.window(driver.window_handles[-1])
    driver.get('https://www.supremenewyork.com/checkout')
    time.sleep(15)
    driver.quit()

def main():
    attack_site()
    #with open(bad_urls_filename, 'w') as f:
        #f.writelines('%s\n' % url for url in bad_urls)

if __name__ == '__main__':
    print(datetime.now())
    main()
    print(datetime.now())